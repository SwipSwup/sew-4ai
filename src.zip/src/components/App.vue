<template>
 <ue05></ue05>
</template>

<script>
import Ue05 from "@/components/ue05/ue05";
export default {
  name: 'App',
  components: {Ue05},
}
</script>

<style scoped>
</style>
