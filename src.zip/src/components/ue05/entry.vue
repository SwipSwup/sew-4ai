<template>
  <div class="container">
    <div class="info">
      <div>{{ name }}</div>
      <div>{{ platz }}</div>
    </div>
    <div>
      <md-radio
        v-for="(_name, index) in disabledButtons"
        v-model="radio"
        :value="index"
        :disabled="disabledButtons[index]"
        @change="updateButtonStatus(index)"
      >
        {{ index + 1 }}
      </md-radio>
    </div>
  </div>
</template>

<script>
export default {
  name: "Entry",
  props: {
    name: String,
    disabledButtons: Array
  },
  data() {
    return {
      radio: true,
      platz: "",
      oldButtonState: undefined
    }
  },
  methods: {
    updateButtonStatus(index) {
      this.platz = index + 1 + ". Platz"
      this.$emit('on-button-update', [index, this.oldButtonState]);
      this.oldButtonState = index
    }
  }
}
</script>

<style scoped>
.container {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.info {
  margin-top: 15px;
  width: 40%;
  display: flex;
  justify-content: space-between;
}
</style>