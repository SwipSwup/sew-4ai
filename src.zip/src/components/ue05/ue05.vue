<template>
  <div>
    <md-card>
      <md-card-header>
        <div class="md-title">Reihung</div>
      </md-card-header>

      <md-card-content>
        <entry @on-button-update="updateButtons($event)" :disabled-buttons="disabledButtons" name="Leesa"></entry>
        <entry @on-button-update="updateButtons($event)" :disabled-buttons="disabledButtons" name="Leesa"></entry>
        <entry @on-button-update="updateButtons($event)" :disabled-buttons="disabledButtons" name="Gamer"></entry>
        <entry @on-button-update="updateButtons($event)" :disabled-buttons="disabledButtons" name="Gamer"></entry>
        <entry @on-button-update="updateButtons($event)" :disabled-buttons="disabledButtons" name="Gamer"></entry>
      </md-card-content>
    </md-card>
  </div>
</template>

<script>
import Entry from "@/components/ue05/entry";
export default {
  name: "ue05",
  components: {Entry},
  data:() => ({
    disabledButtons: [false, false, false, false, false]
  }),

  methods: {
    updateButtons(input) {
      if(input[1] !== undefined) {
        this.$set(this.disabledButtons, input[1], false)
      }
      this.$set(this.disabledButtons, input[0], true)
    }
  }
}
</script>

<style scoped>
  .md-card {
    width: 600px;
  }
  .md-card-header {
    background: #448aff;
    color: #fff;
  }
</style>