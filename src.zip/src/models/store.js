export default {
    state: {
    },

    mutations: {
    },
}
