import Vue from 'vue'

let disabledButtons = [];

export default new Vue();

